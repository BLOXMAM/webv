#!/usr/bin/env python3
"""
يطبّق إعدادات اللوحة (rostrick-build/config.json) على مشروع الأندرويد قبل البناء:
  - اسم التطبيق، applicationId، versionCode، versionName
  - ألوان الثيم
  - أيقونة التطبيق (تُولَّد منها كل الأحجام)
  - رابط الـ Worker داخل: final String ASSET_BASE_HOST = "";

الاستخدام:
  python3 tools/apply_config.py --config <config.json> --project <مجلد المشروع> [--icon <icon.png>]
"""
import argparse
import json
import os
import re
import sys

JAVA_KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
    "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
    "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
    "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
    "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
    "volatile", "while", "true", "false", "null",
}

DEFAULT_COLORS = {
    "primary": "#000000",
    "primary_dark": "#000000",
    "accent": "#000090",
    "highlight": "#000090",
    "control_normal": "#000090",
}

ICON_SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}


def fail(msg):
    print("::error::" + msg)
    sys.exit(1)


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def validate_package(pkg):
    if not isinstance(pkg, str) or not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", pkg):
        fail("اسم الحزمة غير صالح: %r (مثال صحيح: com.mycompany.myapp، أحرف إنجليزية صغيرة وأرقام و _ فقط، وجزءان على الأقل)" % (pkg,))
    for part in pkg.split("."):
        if part in JAVA_KEYWORDS:
            fail("اسم الحزمة يحتوي كلمة محجوزة في Java: " + part)
    if pkg.startswith("android.") or pkg.startswith("com.android."):
        fail("اسم الحزمة محجوز للنظام: " + pkg)
    if len(pkg) > 150:
        fail("اسم الحزمة طويل جداً")


def validate_color(name, value):
    if not isinstance(value, str) or not re.fullmatch(r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})", value):
        fail("لون %s غير صالح: %r (استخدم #RRGGBB)" % (name, value))
    return value.upper()


def clean_host(raw):
    host = (raw or "").strip()
    host = re.sub(r"^https?://", "", host, flags=re.I).strip("/ ")
    host = host.split("/")[0]
    if host and not re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?", host):
        fail("رابط الـ Worker غير صالح: %r" % raw)
    return host


def xml_escape_text(s):
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    s = s.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"')
    s = s.replace("\n", " ")
    if s[:1] in ("@", "?"):
        s = "\\" + s
    return s


def apply_colors(project, colors):
    c = dict(DEFAULT_COLORS)
    c.update({k: v for k, v in (colors or {}).items() if k in DEFAULT_COLORS and v})
    c = {k: validate_color(k, v) for k, v in c.items()}
    xml = (
        "<resources>\n"
        '\t<color name="colorPrimary">%(primary)s</color>\n'
        '\t<color name="colorPrimaryDark">%(primary_dark)s</color>\n'
        '\t<color name="colorAccent">%(accent)s</color>\n'
        '\t<color name="colorControlHighlight">%(highlight)s</color>\n'
        '\t<color name="colorControlNormal">%(control_normal)s</color>\n'
        "</resources>\n"
    ) % c
    write(os.path.join(project, "app/src/main/res/values/colors.xml"), xml)


def apply_strings(project, app_name):
    name = (app_name or "").strip()
    if not name:
        fail("اسم التطبيق فارغ")
    if len(name) > 60:
        fail("اسم التطبيق طويل جداً (الحد 60 حرفاً)")
    xml = (
        "<resources>\n"
        '\t<string name="app_name" translatable="false">%s</string>\n'
        "</resources>\n"
    ) % xml_escape_text(name)
    write(os.path.join(project, "app/src/main/res/values/strings.xml"), xml)


def apply_gradle(project, pkg, version_code, version_name):
    path = os.path.join(project, "app/build.gradle")
    g = read(path)
    g, n1 = re.subn(r'applicationId\s+"[^"]*"', 'applicationId "%s"' % pkg, g, count=1)
    g, n2 = re.subn(r"versionCode\s+\d+", "versionCode %d" % version_code, g, count=1)
    g, n3 = re.subn(r'versionName\s+"[^"]*"', 'versionName "%s"' % version_name.replace('"', ""), g, count=1)
    if (n1, n2, n3) != (1, 1, 1):
        fail("تعذّر تعديل app/build.gradle (لم أجد applicationId/versionCode/versionName)")
    write(path, g)


def apply_worker_host(project, host):
    java_dir = os.path.join(project, "app/src/main/java")
    pattern = re.compile(r'final String ASSET_BASE_HOST = "[^"]*";')
    total = 0
    for root, _, files in os.walk(java_dir):
        for fn in files:
            if not fn.endswith(".java"):
                continue
            p = os.path.join(root, fn)
            src = read(p)
            new, n = pattern.subn('final String ASSET_BASE_HOST = "%s";' % host, src)
            if n:
                write(p, new)
                total += n
    if total != 1:
        fail("توقعت وجود تعريف ASSET_BASE_HOST مرة واحدة بالضبط، وجدت %d" % total)


def apply_icon(project, icon_path):
    if not icon_path or not os.path.isfile(icon_path):
        print("لا توجد أيقونة مخصصة، سيُستخدم الافتراضي.")
        return
    try:
        from PIL import Image
    except ImportError:
        fail("مكتبة Pillow غير مثبتة")
    try:
        img = Image.open(icon_path).convert("RGBA")
    except Exception as e:  # noqa: BLE001
        fail("تعذّر قراءة ملف الأيقونة: %s" % e)
    w, h = img.size
    side = max(w, h)
    if side < 96:
        fail("الأيقونة صغيرة جداً (%dx%d)، الحد الأدنى 96x96 والمستحسن 512x512" % (w, h))
    if w != h:  # نضعها في مربع شفاف بدل تشويهها
        square = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        square.paste(img, ((side - w) // 2, (side - h) // 2))
        img = square
    res = os.path.join(project, "app/src/main/res")
    for d in os.listdir(res):
        if d.startswith("mipmap-"):
            old = os.path.join(res, d, "ic_launcher.png")
            if os.path.exists(old):
                os.remove(old)
    for density, px in ICON_SIZES.items():
        out = os.path.join(res, "mipmap-" + density, "ic_launcher.png")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        img.resize((px, px), Image.LANCZOS).save(out, "PNG", optimize=True)
    print("تم توليد الأيقونة بالأحجام:", ", ".join(ICON_SIZES))


def set_output(key, value):
    path = os.environ.get("GITHUB_OUTPUT")
    line = "%s=%s\n" % (key, value)
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)
    else:
        print("[output]", line.strip())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--project", required=True)
    ap.add_argument("--icon", default="")
    a = ap.parse_args()

    try:
        cfg = json.loads(read(a.config))
    except Exception as e:  # noqa: BLE001
        fail("ملف الإعدادات تالف: %s" % e)

    pkg = cfg.get("package_name")
    validate_package(pkg)

    try:
        version_code = int(cfg.get("version_code"))
    except (TypeError, ValueError):
        fail("رقم الإصدار (version_code) يجب أن يكون رقماً صحيحاً")
    if not (1 <= version_code <= 2100000000):
        fail("رقم الإصدار خارج النطاق المسموح")

    version_name = str(cfg.get("version_name") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9._+\- ]{1,40}", version_name):
        fail("اسم الإصدار (version_name) غير صالح: %r" % version_name)

    host = clean_host(cfg.get("asset_base_host"))
    if not host:
        fail("رابط الـ Worker فارغ: اضبطه في إعدادات اللوحة أولاً")

    apply_strings(a.project, cfg.get("app_name"))
    apply_colors(a.project, cfg.get("colors"))
    apply_gradle(a.project, pkg, version_code, version_name)
    apply_worker_host(a.project, host)
    apply_icon(a.project, a.icon)

    set_output("package_name", pkg)
    set_output("version_code", str(version_code))
    set_output("version_name", version_name.replace(" ", "-"))
    set_output("asset_host", host)
    print("تم تطبيق الإعدادات: %s | %s | v%s (%d) | %s" % (cfg.get("app_name"), pkg, version_name, version_code, host))


if __name__ == "__main__":
    main()
