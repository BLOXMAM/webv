package com.createdby.rostrick;

import android.app.Activity;
import android.view.View;
import android.widget.FrameLayout;

/**
 * نسخة فارغة من طبقة الإعلانات (لا مكتبة ولا شيفرة إعلانية داخل التطبيق).
 * عند تفعيل الإعلانات من إعدادات البناء في RosTrick يستبدلها tools/apply_config.py
 * بالنسخة الحقيقية (AdMob) من tools/RtAdsReal.java.txt ويضيف المكتبة المطلوبة.
 */
final class RtAds {
	interface Listener { void onEvent(String type, String event, int id, boolean ok); }

	static final boolean ENABLED = false;

	RtAds(Activity activity, FrameLayout root, View content) {}
	void setListener(Listener l) {}
	void init() {}
	void showBanner(String position) {}
	void hideBanner() {}
	boolean isReady(String type) { return false; }
	void showInterstitial(int id) {}
	void showRewarded(int id) {}
	void onPause() {}
	void onResume() {}
	void onDestroy() {}
}
