package com.createdby.rostrick;

import android.app.Activity;

/**
 * نسخة فارغة من طبقة الشراء داخل التطبيق (لا مكتبة فوترة داخل التطبيق).
 * عند تفعيل الشراء في إعدادات البناء يستبدلها tools/apply_config.py بالنسخة الحقيقية
 * (Google Play Billing) من tools/RtBillingReal.java.txt ويضيف المكتبة.
 */
final class RtBilling {
	interface Callback { void done(int id, String json); }

	static final boolean ENABLED = false;

	RtBilling(Activity activity, Callback cb) {}
	void init() {}
	void getProducts(int id, String idsJson, String type) {}
	void buy(int id, String productId, String type, boolean consumable, String offerToken) {}
	void getPurchases(int id) {}
	void consume(int id, String token) {}
	void onDestroy() {}
}
